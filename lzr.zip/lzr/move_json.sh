#!/bin/bash

# Ensure the 'lzr/json' directory exists
# mkdir -p lzr/json_files

# Find and move all 'default*.json' files to 'lzr/json'
find . -maxdepth 1 -name "default*.json" -exec mv {} json_files/ \;

# Print confirmation message
# echo "All 'default*.json' files have been moved to 'json_files/'."