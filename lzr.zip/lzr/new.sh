#!/bin/bash
make all source-ip=10.0.2.15
cat ./services_list | sudo ./lzr --handshakes http -sendSYNs -sourceIP 10.0.2.15 -gatewayMac 08:00:27:42:2d:76 -sendInterface enp0s3 -rate 30

./move_json.sh

stty sane

# 20ish, copy ports mix n match between all expected, bit of both
# check time sleep at stages
