#!/bin/bash
make all source-ip=10.0.2.15
sudo zmap --allowlist-file=new_test_file --target-port=9000 --sender-threads=3 \
--cores=1,2,3 --output-filter="success = 1 && repeat = 0" \
-f "saddr,daddr,sport,dport,seqnum,acknum,window" -O json \
--source-ip=10.0.2.15 -i enp0s3 --rate=10000 | \
sudo ./lzr --handshakes http,tls -sendInterface enp0s3 -sourceIP 10.0.2.15 \
-gatewayMac "52:54:00:12:35:02" -onlyDataRecord -w 8 -f new.json

stty sane

