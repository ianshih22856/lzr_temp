package handshakes

import "github.com/stanford-esrg/lzr/handshakes/newlines"

func init() {
	newlines.RegisterHandshake()
}

