package handshakes

import "github.com/stanford-esrg/lzr/handshakes/ftp"

func init() {
	ftp.RegisterHandshake()
}

