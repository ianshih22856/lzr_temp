package handshakes

import "github.com/stanford-esrg/lzr/handshakes/oracle"

func init() {
	oracle.RegisterHandshake()
}

