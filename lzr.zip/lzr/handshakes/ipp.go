package handshakes

import "github.com/stanford-esrg/lzr/handshakes/ipp"

func init() {
	ipp.RegisterHandshake()
}

