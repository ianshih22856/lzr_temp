package handshakes

import "github.com/stanford-esrg/lzr/handshakes/rtsp"

func init() {
	rtsp.RegisterHandshake()
}

