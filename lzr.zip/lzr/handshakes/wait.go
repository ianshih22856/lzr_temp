package handshakes

import "github.com/stanford-esrg/lzr/handshakes/wait"

func init() {
	wait.RegisterHandshake()
}

