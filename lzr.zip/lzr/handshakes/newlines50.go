package handshakes

import "github.com/stanford-esrg/lzr/handshakes/newlines50"

func init() {
	newlines50.RegisterHandshake()
}

