package handshakes

import "github.com/stanford-esrg/lzr/handshakes/pptp"

func init() {
	pptp.RegisterHandshake()
}

