package handshakes

import "github.com/stanford-esrg/lzr/handshakes/x11"

func init() {
	x11.RegisterHandshake()
}

