package handshakes

import "github.com/stanford-esrg/lzr/handshakes/dnp3"

func init() {
	dnp3.RegisterHandshake()
}

