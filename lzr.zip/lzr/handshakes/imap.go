package handshakes

import "github.com/stanford-esrg/lzr/handshakes/imap"

func init() {
	imap.RegisterHandshake()
}

