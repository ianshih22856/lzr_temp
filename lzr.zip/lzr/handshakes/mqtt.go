package handshakes

import "github.com/stanford-esrg/lzr/handshakes/mqtt"

func init() {
	mqtt.RegisterHandshake()
}

