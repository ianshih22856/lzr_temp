package handshakes

import "github.com/stanford-esrg/lzr/handshakes/dns"

func init() {
	dns.RegisterHandshake()
}

