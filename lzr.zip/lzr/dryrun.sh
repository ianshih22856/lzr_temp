#!/bin/bash
make all source-ip=10.0.2.15

sudo zmap --target-port=9000 -o - --source-ip=10.0.2.15 -n 50 --cooldown-time=2 --dryrun 104.81.3.98/20 | sudo ./lzr --handshakes http -dryrun -sourceIP 10.0.2.15 -gatewayMac 08:00:27:42:2d:76 -sendInterface enp0s3

./move_json.sh

stty sane