/*
Copyright 2020 The Board of Trustees of The Leland Stanford Junior University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package lzr

import (
	"fmt"
	"sync/atomic"
)

var expCallCount uint64

func handleExpired( opts *options, packet * packet_metadata, ipMeta * pState,
	timeoutQueue chan *packet_metadata, writingQueue chan *packet_metadata ) {
		
	atomic.AddUint64(&expCallCount, 1)
	fmt.Println("HANDLE EXPIRED 29 handle expired call,", expCallCount, "|", packet.Saddr, ":", packet.Sport, ",", packet.Dport)

	// first close the existing connection unless
	// its already been terminated
	if !( packet.RST && !packet.ACK ) && !(packet.ExpectedRToLZR == SYN_ACK) {

		rst := constructRST( packet )
		_ = handle.WritePacketData( rst )

	}

	//grab which handshake
	handshakeNum := ipMeta.getHandshake( packet )

	//if we are all not trying anymore handshakes, so sad.
	//because:
	//1. it was a HAF packet to begin with
	//2. we have run out of handshakes
	//3. doesnt synack 
	//if ( packet.ExpectedRToLZR == SYN_ACK ||
	// if hyperack or last handshakenum or expect synack and not forceall
	if ( packet.HyperACKtive  || (handshakeNum >= (len( opts.Handshakes ) - 1)) ||
		(packet.ExpectedRToLZR == SYN_ACK  && !ForceAllHandshakes() )){
		// fmt.Println("HANDLE EXP 47 handshake num:", handshakeNum, ", len=", len(opts.Handshakes) - 1, ", opts.hs:", opts.Handshakes)
		packet.syncHandshakeNum( handshakeNum )

		//document failure if its a handshake response that hasnt succeeded before
		// if packet is not hyperack and forceall=false, or getdata=false, or hasdata=true
		if !packet.HyperACKtive && !( ForceAllHandshakes() && ipMeta.getData( packet ) && !(packet.hasData())) {
			// true if packet has data or recordonlydata is false
			// fmt.Println("HANDLE EXP 53: forceall_f:", ForceAllHandshakes(), ", getdata_f:", ipMeta.getData(packet), ", hasdata_t:", packet.hasData())
			if !(!(packet.hasData()) && RecordOnlyData()) {
				// fmt.Println("HANDLE EXP 55:", "hasdata:", packet.hasData(), ", reconly:", RecordOnlyData(), ", addrs:", packet.Saddr, packet.Sport, packet.Daddr, packet.Dport)
				writingQueue <- packet
			} else {
				addToSummary(packet)
			}

		}

		//remove from state, we are done now
		packet = ipMeta.remove( packet )
		if HyperACKtiveFiltering() {
			packet.HyperACKtive = true
			packet = ipMeta.remove( packet )
		}
	} else { // lets try another handshake


		//record all succesful fingerprints if forcing all handshakes
		if ForceAllHandshakes() && packet.hasData() {
			packet.syncHandshakeNum( handshakeNum )
			// fmt.Println("HANDLE EXP 73:", packet.Saddr, packet.Sport, packet.Daddr, packet.Dport)
			writingQueue <- packet
		}

		packet.updatePacketFlow()
		ipMeta.incHandshake( packet )
		// fmt.Println("SEND SYN HAND EXPIRED")
		SendSyn( packet, ipMeta, timeoutQueue )

		//lets also filter for HyperACKtive hosts
		if ( handshakeNum == 0 &&  HyperACKtiveFiltering() ) {
			for i := 0; i < getNumFilters(); i++ {
				highPortPacket := createFilterPacket( packet )
				SendSyn( highPortPacket, ipMeta, timeoutQueue )
				ipMeta.incHandshake( highPortPacket )
				ipMeta.setHyperACKtiveStatus( highPortPacket )

				ipMeta.setParentSport( highPortPacket, packet.Sport )
				ipMeta.FinishProcessing( highPortPacket )
			}
		}

	}

}

